using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;

namespace NUnitTest
{
    public class Tests
    {
        [SetUp]
        public void Setup() 
        {

        }

        [Test]
        public void Test1()
        {

            IWebDriver webDriver = new ChromeDriver();
            webDriver.Navigate().GoToUrl("https://s1.demo.opensourcecms.com/wordpress/wp-login.php");
            webDriver.Manage().Window.Maximize();

            //p�ihl�en�
            webDriver.FindElement(By.Id("user_login")).SendKeys("opensourcecms");

            webDriver.FindElement(By.Name("pwd")).SendKeys("opensourcecms" + Keys.Enter);
            System.Threading.Thread.Sleep(1000);

            webDriver.FindElement(By.XPath("/html/body/div[1]/div[1]/div[2]/ul/li[3]/ul/li[5]/a")).Click();
            System.Threading.Thread.Sleep(1000);

            /*webDriver.FindElement(By.XPath("/html/body/div[1]/div[1]/div[2]/ul/li[3]/ul/li[5]/a")).Click();
            System.Threading.Thread.Sleep(1000);*/

            //vytvo�en� tagu

            var verifyTag = webDriver.FindElement(By.Id("tag-name"));

            verifyTag.SendKeys("1234" + Keys.Enter);
            System.Threading.Thread.Sleep(1000);

            //nalezen� atributu
            IWebElement findAtribut = webDriver.FindElement(By.TagName("body"));

            Assert.IsTrue(findAtribut.Text.Contains("1234"));


            //odstran�n� tagu
            /*webDriver.FindElement(By.XPath("/html/body/div[1]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/form/table/tbody/tr/td[1]/strong/a")).Click();
            webDriver.FindElement(By.XPath("/html/body/div/div[2]/div[2]/div[1]/div[3]/form/div/span/a")).Click();

            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(8);

            verifyTag.Submit();*/

            var notNull = webDriver.FindElement(By.Id("tag-descrption"+ Keys.Enter));

            //Assert.IsNotNull()


        }
    }
}